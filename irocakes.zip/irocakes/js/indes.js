// window.onscroll = function()
// {
//     scrollFunction();
// }
// function scrollFunction()
// {
//     if(document.body.scrollTop >80 || document.documentElement.scrollTop >80)
//     {
//         document.getElementById('navbar').style.padding ="5px 0px";
//         document.getElementById('logo').style.fontSize ="15px";
//     }
//     else
//     {
//         document.getElementById('navbar').style.padding="10px 0px";
//         document.getElementById('logo').style.fontSize="20px";
//     }
// }

// var height=$('#navbar').height();
// $(window).scroll(function(){
//     if($(this).scrollTop()>height)
//     {
//         $('.navbar').addClass('fixed');
//     }
//     else
//     {
//         $('.navbar').removeClass('fixed');
//     }
// });

// (function($) {
//     "use strict";

// $(window).on('load', function() {
//     var pre_loader = $('.preloader');
//     pre_loader.fadeOut('slow', function() {
//       $(this).remove();
//     });
//   });

//   $(window).load(function() {
//     setTimeout(function(){ $('#preloader').fadeOut('slow'); }, 3000);
//  })

// })(jQuery);

// var preloader =document.getElementById('preloader');

// function  myFunction()
// {
//     preloader.style.display='none';

// }